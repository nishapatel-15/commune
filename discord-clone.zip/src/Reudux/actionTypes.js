// user reducer types
export const LOGIN = "login";

// server reducer typse
export const SET_SERVER_LOADING = "setloading";
export const ADD_JOINED_SERVER = "addToJoinedServers";
export const SET_CURRENT_SELECTED = "setCurrentSelected";
export const ADD_TOTAL_SERVER = "addToTotalServers";
export const SET_LOADING_TOTAL_SERVERS = "setLoadingTotalServers";
export const SELECT_SERVER = "selectServer";
export const UPDATE_SERVER = "updateServer";
export const REMOVE_SERVER = "removeServer";
export const ADD_MESSAGES = "addMessages";
export const ADD_MESSAGE = "addMessage";
export const ADD_DM = "addDm";
export const SET_CALL = "setCall";
